<?php $__env->startSection('title', 'Ediciones El Profesional'); ?>
<?php $__env->startSection('description', 'La mejor experiencia y poner a tu disposicion el catalogo de mejor calidad de libros especializados, técnicos y científicos disponibles en el país.'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-3">
  <div class="bg-white">
    <div class="row">
      <div class="col-md-8 col-lg-9">
        <div class="lineTitle">
          <h2>
            <small>Catalogo</small>
            Ediciones el Profesional
          </h2>
        </div>
        <div class="row py-3">
          <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-sm-6 col-md-4">
            <div class="bookList">
              <a href="<?php echo e(route('book', $book->slug)); ?>" class="cover">
                <div class="price py-1 px-2">
                  <s>$ <?php echo e($book->old_price > 0 ? number_format($book->old_price) : ''); ?></s>
                  <span>$ <?php echo e(number_format($book->price)); ?></span>
                </div>
                <img src="<?php echo e(isset($book->picture) ? $book->picture : '/img/no-cover.jpg'); ?>" class="img-fluid">
              </a>
              <h5>
                <?php echo e($book->name); ?>

                <small>
                  <?php echo e($book->publisher->name); ?>

                  <?php $__currentLoopData = $book->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($author->name); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </small>
              </h5>
              <div class="text-center">
                <div class="btn-group" role="group" aria-label="Book actions">
                  <a href="<?php echo e(route('book', $book->slug)); ?>" class="btn btn-sm btn-outline-info"><i class="fa fa-plus"></i> Info</a>
                  <a href="<?php echo e(route('cartAdd', $book->id)); ?>" class="btn btn-sm btn-outline-success"><i class="fas fa-cart-plus"></i> Comprar</a>
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="col-md-4 col-lg-3">
        <h5>Temas</h5>
        <div class="list-group">
          <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(route('storeTopic', ['topic' => $topic->slug])); ?>" class="list-group-item bg-light"><?php echo e($topic->name); ?></a>
            <?php $__currentLoopData = $topic->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topicChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('storeTopic', ['topic' => $topicChild->slug])); ?>" class="list-group-item py-1"><?php echo e($topicChild->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>