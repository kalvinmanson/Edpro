<?php $__env->startSection('title', 'Ediciones El Profesional'); ?>
<?php $__env->startSection('description', 'La mejor experiencia y poner a tu disposicion el catalogo de mejor calidad de libros especializados, técnicos y científicos disponibles en el país.'); ?>

<?php $__env->startSection('content'); ?>
  <div id="carroHome" class="carroHome carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <?php $bannersi = 0; ?>
      <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li data-target="#carroHome" data-slide-to="<?php echo e($bannersi++); ?>" class="<?php echo e($bannersi == 0 ? 'active' : ''); ?>"></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
    <div class="carousel-inner">
      <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item <?php if(!isset($bannersitem)) { echo 'active'; $bannersitem = 1; } ?>">
        <a href="<?php echo e($banner->link); ?>">
          <img class="d-block w-100 animated fadeIn" src="<?php echo e($banner->picture); ?>" alt="<?php echo e($banner->name); ?>">
        </a>
        <?php if($banner->description): ?>
        <div class="carousel-caption d-none d-md-block text-left animated fadeInDown">
          <h5><?php echo e($banner->name); ?></h5>
          <p><?php echo e($banner->description); ?></p>
          <a href="#" class="btn btn-outline-success">Ver más...</a>
        </div>
        <?php endif; ?>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a class="carousel-control-prev" href="#carroHome" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carroHome" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
<div class="container">
  
  <div class="bg-white">
    <div class="lineTitle">
      <a href="<?php echo e(route('store')); ?>" class="btn btn-sm btn-outline-success float-right">Ver todos</a>
      <h2>
        <small>Descubre lo libros</small>
        Más vendidos.
      </h2>
    </div>
    <div class="row py-3">
      <?php $__currentLoopData = $topBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-6 col-md-3">
        <div class="bookList">
          <a href="<?php echo e(route('book', $book->slug)); ?>" class="cover">
            <div class="price py-1 px-2">
              <s>$ <?php echo e($book->old_price > 0 ? number_format($book->old_price) : ''); ?></s>
              <span>$ <?php echo e(number_format($book->price)); ?></span>
            </div>
            <img src="<?php echo e(isset($book->picture) ? $book->picture : '/img/no-cover.jpg'); ?>" class="img-fluid">
          </a>
          <h5>
            <?php echo e($book->name); ?>

            <small>
              <?php echo e($book->publisher->name); ?>

              <?php $__currentLoopData = $book->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($author->name); ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </small>
          </h5>
          <div class="text-center">
            <div class="btn-group" role="group" aria-label="Book actions">
              <a href="<?php echo e(route('book', $book->slug)); ?>" class="btn btn-sm btn-outline-info"><i class="fa fa-plus"></i> Info</a>
              <a href="<?php echo e(route('cartAdd', $book->id)); ?>" class="btn btn-sm btn-outline-success"><i class="fas fa-cart-plus"></i> Comprar</a>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="lineTitle">
      <h2>
      <h2>
        <small>Actualidad</small>
        Noticias y eventos
      </h2>
    </div>
    <div class="row">
      <div class="col-md-7">
        <?php $__currentLoopData = $lastPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
          <img class="card-img-top" src="<?php echo e($post->picture ? $post->picture : '/img/clips/news.jpg'); ?>" alt="<?php echo e($post->name); ?>">
          <div class="card-body">
            <a href="<?php echo e(route('blog', $post->slug)); ?>">
              <h5 class="card-title m-0"><?php echo e($post->name); ?></h5>
            </a>
            <p class="card-text p-0 m-0"><small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small></p>
            <p class="card-text"><?php echo e($post->description); ?></p>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="col-md-5">

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>