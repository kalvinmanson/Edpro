<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-8 col-lg-9">
      <form action="<?php echo e(route('admin.pages.update', $page->id)); ?>" method="POST" class="card">
        <input type="hidden" name="_method" value="PUT">
        <?php echo csrf_field(); ?>
        <div class="card-header">Edit page: <?php echo e($page->name); ?></div>
        <div class="card-body">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" class="form-control form-control-lg" value="<?php echo e(old('name') ? old('name') : $page->name); ?>" required>
          </div>
          <div class="form-group">
            <input type="text" name="slug" id="slug" class="form-control form-control-sm" placeholder="slug-of-the-content" value="<?php echo e(old('slug') ? old('slug') : $page->slug); ?>" required>
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="description">Description</label>
                <textarea type="text" name="description" id="description" class="form-control" rows="5"><?php echo e(old('description') ? old('description') : $page->description); ?></textarea>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="picture">Picture</label>
                <upload-input name="picture" value="<?php echo e(old('picture') ? old('picture') : $page->picture); ?>"></upload-input>
              </div>
              <div class="form-group">
                <label for="weight">weight</label>
                <input type="number" name="weight" id="weight" class="form-control" value="<?php echo e(old('weight') ? old('weight') : $page->weight); ?>">
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="categories">Categories</label>
                <select name="categories[]" id="categories" class="form-control" multiple>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e($page->categories->where('id', $category->id)->first() ? 'selected' : ''); ?>><?php echo e($category->parent ? $category->parent->name.' / ' : ''); ?><?php echo e($category->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="content">Content</label>
            <editor name="content" value="<?php echo e(old('content') ? old('content') : $page->content); ?>"></editor>
          </div>
        </div>
        <div class="card-footer">
          <a class="btn btn-danger btn-sm float-right" href="#" onclick="event.preventDefault(); document.getElementById('destroy-form').submit();">
              <i class="far fa-trash-alt"></i> Destroy
          </a>
          <button type="submit" class="btn btn-primary">Save</button>
        </div>
      </form>
    </div>
    <div class="col-md-8 col-lg-3">
      <?php echo $__env->make('partials.admin.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
</div>

<form id="destroy-form" action="<?php echo e(route('admin.pages.destroy', $page->id)); ?>" method="POST" style="display: none;">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="_method" value="DELETE" />
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>