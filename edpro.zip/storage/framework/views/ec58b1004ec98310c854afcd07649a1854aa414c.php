<?php if(Auth::check()): ?>
  <div class="card">
    <div class="card-body">
      <form method="POST" action="<?php echo e(route('addcomment', $book->slug)); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <textarea name="content" class="form-control" placeholder="Escribe tu comentario..." required></textarea>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-success">Enviar</button>
        </div>

      </form>
    </div>
  </div>
<?php else: ?>
<?php endif; ?>
