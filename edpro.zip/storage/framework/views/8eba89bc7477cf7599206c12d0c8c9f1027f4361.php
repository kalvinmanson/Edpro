<?php $__env->startSection('title', 'Completa tu pedido'); ?>
<?php $__env->startSection('description', 'Realiza tus compras en libros academicos de zootécnia y veterinaria especializada.'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="lineTitle">
      <h2>
        <small>Carro de compra</small>
        Completa tu pedido
      </h2>
    </div>
    <div class="row">
      <div class="col-md-8">
        <?php if(count($carts) > 0): ?>
          <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
              <div class="card-body">
                <div class="float-right text-right">
                  <small><s>$ <?php echo e(number_format($cart->model->old_price)); ?></s></small><br>
                  <?php if($cart->qty == 1): ?>
                    <strong> $ <?php echo e(number_format($cart->model->price)); ?></strong>
                  <?php else: ?>
                    (x<?php echo e($cart->qty); ?>)<strong> $ <?php echo e(number_format($cart->model->price * $cart->qty)); ?></strong>
                  <?php endif; ?>
                </div>
                <strong><a href="<?php echo e(route('book', $cart->model->slug)); ?>" target="_blank"><?php echo e($cart->model->name); ?></a></strong><br>
                <small>
                  Autor(es): <?php $__currentLoopData = $cart->model->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($author->name); ?>,
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <br> Editorial: <?php echo e($cart->model->publisher->name); ?>

                </small>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          
        <?php endif; ?>
        <div class="text-secondary p-4">
          <p>Ediciones el profesional envia actualmente a todas las ciudades principales dle territorio Colombiano y algunos paises de latinoamerica cuando el cliente asume los costos de envio.</p>
        </div>
      </div>
      <div class="col-md-4">
        <?php echo $__env->make('partials.cart.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>