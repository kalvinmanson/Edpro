<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">

</head>
<body>
  <div id="app">
    <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
      <div class="container">
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="bg-dark text-white py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
          </div>
        </div>
        <p>
          <small>
            &copy; 2018 Todos los derechos reservados por Ediciones el Profesional LTDA.<br>
            Desarrollado por <a href="//droni.co" title="Desarrollo Inteligente">Droni.co</a>.
          </small>
        </p>
      </div>
    </footer>
  </div>
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</body>
</html>
