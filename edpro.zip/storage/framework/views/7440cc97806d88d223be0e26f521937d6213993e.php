<header class="animated fadeInDown">
  <div class="miniTop">
    <div class="container">
      <ul>
        <li><a href="#">Sobre nosotros</a></li>
        <li><a href="#">Contacto</a></li>
        <li><a href="#">Ayuda</a></li>
        <li><a href="#">Español</a></li>
        <li><a href="/cart">Cart</a></li>
      </ul>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-md-2">
        <a href="<?php echo e(route('home')); ?>" title="Ediciones El Profesional LTDA.">
          <img src="/img/logo-ediciones-el-profesional-w.png" class="img-fluid py-2" alt="Ediciones El Profesional LTDA.">
        </a>
      </div>
      <div class="col-md-10">
        <div class="topCart">
          <cart session="<?php echo e(Session::getId()); ?>"></cart>
          <div class="loginBox p-3 text-right float-right">
          <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>" class="text-white">Iniciar sesión</a> <br>
            <a href="<?php echo e(route('register')); ?>" class="text-white">¿Eres nuevo? Registrate</a>
          <?php else: ?>
            <span class="text-white"><?php echo e(Auth::user()->name); ?></span> <br>
            <a href="#" class="text-white">Mi cuenta</a> |
            <a href="<?php echo e(route('logout')); ?>" class="text-white" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Salir <i class="fas fa-power-off"></i></a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
          <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <nav class="navbar navbar-expand-md navbar-light p-0">
    <div class="container">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
          <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <!-- Left Side Of Navbar -->
        <ul class="navbar-nav mr-auto navbar-justify">
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('blog')); ?>">Actualidad</a></li>
          <li class="nav-item"><a class="nav-link" data-toggle="collapse" href="#catalogo">Catálogo</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Eventos</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Promociones</a></li>
        </ul>
        <form action="<?php echo e(route('search')); ?>" method="GET" class="form-inline my-2 my-lg-0">
          <input class="form-control" name="q" type="search" placeholder="<?php echo e(Request::get('q') ? Request::get('q') : 'Equinos...'); ?>" aria-label="Buscar">
          <button class="btn btn-primary my-2 my-sm-0" type="submit">Buscar</button>
        </form>
      </div>
    </div>
  </nav>
  <div class="container collapse" id="catalogo">
    <div class="card card-body">
      <div class="row">
        <div class="col-md-8">
          <h4>Temas</h4>
          <ul class="menuColumns">
            <?php $__currentLoopData = App\Topic::where('parent_id', 0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <a href="<?php echo e(route('storeTopic', ['topic' => $topic->slug])); ?>" title="Libros de <?php echo e($topic->name); ?>"><?php echo e($topic->name); ?></a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <div class="col-md-4">
          <h4>Recomendado</h4>
          <?php $__currentLoopData = App\Book::orderBy('rank', 'desc')->limit(1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
              <div class="card-body">
                <div class="miniBook">
                  <img src="<?php echo e(isset($book->picture) ? $book->picture : '/img/no-cover.jpg'); ?>" class="img-fluid">
                  <a href="<?php echo e(route('book', $book->slug)); ?>" title="Libro: <?php echo e($book->name); ?>">
                    <h5><?php echo e($book->name); ?></h5>
                  </a>
                  <small>
                    <?php echo e($book->publisher->name); ?>

                    <?php $__currentLoopData = $book->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($author->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </small>
                  <div class="price py-1 px-2">
                    <s>$ <?php echo e($book->old_price > 0 ? number_format($book->old_price) : ''); ?></s>
                    <span>$ <?php echo e(number_format($book->price)); ?></span>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</header>
