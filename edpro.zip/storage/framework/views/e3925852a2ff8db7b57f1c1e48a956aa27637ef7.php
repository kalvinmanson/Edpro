<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <attachments :attachments="<?php echo e($attachments); ?>" editor="<?php echo e($isEditor); ?>"></attachments>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blank', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>