<?php $__env->startSection('title', 'Ediciones El Profesional'); ?>
<?php $__env->startSection('description', 'La mejor experiencia y poner a tu disposicion el catalogo de mejor calidad de libros especializados, técnicos y científicos disponibles en el país.'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="lineTitle">
    <h2>
      <small>Noticias y Novedades</small>
      Blog de actualidad.
    </h2>
  </div>
  <div class="row">
    <div class="col-md-8 col-lg-9">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card mb-3">
        <img class="card-img-top" src="<?php echo e($post->picture ? $post->picture : '/img/clips/news.jpg'); ?>" alt="<?php echo e($post->name); ?>">
        <div class="card-body">
          <a href="<?php echo e(route('blog', $post->slug)); ?>">
            <h5 class="card-title m-0"><?php echo e($post->name); ?></h5>
          </a>
          <p class="card-text p-0 m-0"><small class="text-muted"><?php echo e($post->created_at->diffForHumans()); ?></small></p>
          <p class="card-text"><?php echo e($post->description); ?></p>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-md-4 col-lg-3">

    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>