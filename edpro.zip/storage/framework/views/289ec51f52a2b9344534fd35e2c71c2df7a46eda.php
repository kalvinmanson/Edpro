<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#addNew"><i class="fa fa-plus"></i> Add new</button>
  <h1>Books</h1>
  <table class="table table-striped">
    <tr>
      <th width="20">Id</th>
      <th>Name</th>
      <th>Book Info</th>
      <th>Topics</th>
      <th>Author</th>
      <th>Picture</th>
      <th>Stock</th>
      <th>Price</th>
      <th>Timestamps</th>
    </tr>
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($book->id); ?></td>
      <td>
        <a href="<?php echo e(route('admin.books.edit', $book->id)); ?>"><strong><?php echo e($book->name); ?></strong></a><br>
        <small><a href="#">/<?php echo e($book->slug); ?></a>
      </td>
      <td>
        Publisher: <?php echo e($book->publisher->name); ?><br>
        Year: <?php echo e($book->year); ?><br>
        Pages: <?php echo e($book->pages); ?>

      </td>
      <td>
        <?php $__currentLoopData = $book->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($topic->name); ?>,
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </td>
      <td>
        <?php $__currentLoopData = $book->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($author->name); ?>,
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </td>
      <td><a href="<?php echo e($book->picture); ?>" data-fancybox="gallery"><?php echo e($book->picture); ?></a></td>
      <td><?php echo e($book->stock); ?></td>
      <td>
        <small><strike>$ <?php echo e(number_format($book->old_price)); ?> COP</strike></small><br>
        <strong>$ <?php echo e(number_format($book->price)); ?> COP</strong>
      </td>
      <td>
        <small>
          Created at <?php echo e($book->created_at); ?>,<br>
          Last update <?php echo e($book->updated_at->diffForHumans()); ?>

        </small>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php echo e($books->links()); ?>

</div>


<!-- Modal -->
<div class="modal fade" id="addNew" tabindex="-1" role="dialog" aria-labelledby="addNewLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form action="<?php echo e(route('admin.books.store')); ?>" method="POST" class="modal-content">
      <?php echo csrf_field(); ?>
      <div class="modal-header">
        <h5 class="modal-title" id="addNewLabel">Add new</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="publisher_id">Publisher</label>
          <select name="publisher_id" id="publisher_id" class="form-control">
            <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($publisher->id); ?>"><?php echo e($publisher->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label for="name">Name</label>
          <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>
        <div class="form-group">
          <input type="text" name="slug" id="slug" class="form-control form-control-sm" placeholder="slug-of-the-content" value="<?php echo e(old('slug')); ?>" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>